from django import forms

class Img(forms.Form):
    image = forms.ImageField(label='image：')
