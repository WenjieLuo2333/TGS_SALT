from django.db import models
import datetime
from django.utils import timezone

from django.db import models

# 用来保存上传图片相关信息的模型
class Profile(models.Model):
    pic = models.ImageField(upload_to = 'uploads/', default = 'uploads/None/no-img.jpg')

class img(models.Model):
    name = models.CharField(max_length=250,default = '')
    pic = models.ImageField(upload_to='uploads/')