from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from tgs.forms import Img # 上传图片的图表
from tgs.models import img # 保存上传图片相关信息的模型

import os,sys

import numpy as np
import pandas as pd

from random import randint

import matplotlib.pyplot as plt
plt.style.use('seaborn-white')
import seaborn as sns
sns.set_style("white")
import tensorflow as tf
from sklearn.model_selection import train_test_split

from skimage.transform import resize

from keras.preprocessing.image import load_img
from keras import Model
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from keras.models import load_model
from keras.optimizers import Adam
from keras.utils.vis_utils import plot_model
from keras.preprocessing.image import ImageDataGenerator
from keras.layers import Input, Conv2D, Conv2DTranspose, MaxPooling2D, concatenate, Dropout,BatchNormalization,Activation,Add
from tensorflow import keras
from tqdm import tqdm_notebook
from keras import backend as K
from keras import optimizers
import time
import copy
img_size_ori = 101
img_size_target = 128


def upsample(img):
    if img_size_ori == img_size_target:
        return img
    return resize(img, (img_size_target, img_size_target), mode='constant', preserve_range=True)
    #res = np.zeros((img_size_target, img_size_target), dtype=img.dtype)
    #res[:img_size_ori, :img_size_ori] = img
    #return res
    
def downsample(img):
    if img_size_ori == img_size_target:
        return img
    return resize(img, (img_size_ori, img_size_ori), mode='constant', preserve_range=True)


def result(request):
	context = {} 
	return render(request, 'tgs/uploaded.html', context)

def index(request):

	context = {} 
	return render(request, 'tgs/index.html', context)

def uploaded(request):
    K.clear_session()
    if request.method == 'POST':
        root='./tgs/static/uploads/uploads/'
        for root, dirs, files in os.walk(root):
        	for i in files:
        		os.remove(root+i)
        global model
        c=img.objects.all()
        c.delete()
        form = Img(request.POST, request.FILES)
        name = request.FILES
        if form.is_valid():
            pic = img()
            pic.pic = form.cleaned_data["image"]
            pic.name=pic.pic.name
            pic.save()
            model={}
            K.clear_session()
            model = load_model('/home/wenjie/Desktop/TGS/keras.model')
            model.predict(np.zeros((1, 128,128,1)))
            x_test = np.array([upsample(np.array(load_img(root+pic.name, color_mode = "grayscale"))) ]).reshape(-1, 128, 128, 1)
            
            preds_test = model.predict(x_test)
            threshold = 0.5714285714285714


            tmps=[]
            tmp=[]
            for i in x_test[0]:
                for j in i:
                    tmp.append(j[0])
                tmps.append(tmp)
                tmp = []
            tmps=np.array(tmps)
            tmp_ori=tmps

            tmps=[]
            tmp=[]
            for i in preds_test[0]:
                for j in i:
                    tmp.append(j[0])
                tmps.append(tmp)
                tmp = []
            tmps=np.array(tmps)
            ax=plt.imshow(tmp_ori,cmap='Greys')
            ax=plt.imshow(tmps, alpha=0.3, cmap="Greens")
            plt.savefig('./tgs/static/img/outfile.png')
            keras.backend.clear_session()
            return HttpResponseRedirect('http://localhost:8000/tgs/uploaded/result')

            #return render(request, 'tgs/uploaded.html', {'name': info})
    else:
        form = UploadFileForm()
    return render(request, 'tgs/uploaded.html', {'form': form})