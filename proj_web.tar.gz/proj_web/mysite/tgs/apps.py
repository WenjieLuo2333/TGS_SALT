from django.apps import AppConfig


class TgsConfig(AppConfig):
    name = 'tgs'
